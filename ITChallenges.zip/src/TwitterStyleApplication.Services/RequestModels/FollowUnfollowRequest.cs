﻿namespace TwitterStyleApplication.Services.RequestModels
{
    public class FollowUnfollowRequest
    {
		public string Username { get; set; }
    }
}
